---
title: "Example Story"
date: 2025-05-21T00:00:00Z
---

This is a sample story to show how Netlify CMS works.
